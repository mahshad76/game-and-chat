package view;


import tools.History;
import model.RequestLoginMessage;
import tools.SocketClient;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;

public class ChatFrame extends JFrame {

    public SocketClient client;//
    public int port;
    public String serverAddr, username, password;
    public Thread clientThread;
    public DefaultListModel model;//graphic
    public File file;
    public String historyFile = "c:\\users\\mahnoosh\\desktop\\history.xml";

    public History hist;
    boolean flag=false;
    public ArrayList<ArrayList<Integer>> colored=new ArrayList<>();

    public int count1=0;
    String target ="";
    public JFrame jFrame=new JFrame();   public JButton[][] grid;
    public ChatFrame() {

        initComponents();
        this.setTitle("jMessenger");




        jTextField6.setEditable(false);



         hist = new History(historyFile);
    }



    private void initComponents() {

        jLabel1 = new JLabel();
        jTextField1 = new JTextField();
        jLabel2 = new JLabel();
        jTextField2 = new JTextField();
        jButton1 = new JButton();
        jTextField3 = new JTextField();
        jLabel3 = new JLabel();
        jLabel4 = new JLabel();
        jButton3 = new JButton();
        jPasswordField1 = new JPasswordField();
        jSeparator1 = new JSeparator();
        jScrollPane1 = new JScrollPane();
        jTextArea1 = new JTextArea();
        jScrollPane2 = new JScrollPane();
        jList1 = new JList();
        jLabel5 = new JLabel();
        jTextField4 = new JTextField();
        jButton4 = new JButton();
        jButton2 = new JButton();
        jSeparator2 = new JSeparator();
        jTextField5 = new JTextField();
        jButton5 = new JButton();
        jButton6 = new JButton();
        jLabel6 = new JLabel();
        jLabel7 = new JLabel();
        jTextField6 = new JTextField();
        jButton7 = new JButton();
        jButton8 = new JButton();




        jLabel1.setText("Host Address : ");

        jTextField1.setText("localhost");

        jLabel2.setText("Host Port : ");

        jTextField2.setText("13000");

        jButton1.setText("Connect");
        jButton1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jTextField3.setText("mahnoosh");
        jTextField3.setEnabled(false);

        jLabel3.setText("Password :");

        jLabel4.setText("Username :");

        jButton3.setText("");
        jButton3.setEnabled(false);


        jPasswordField1.setText("1234");
        jPasswordField1.setEnabled(false);

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jList1.setModel((model = new DefaultListModel()));
        jScrollPane2.setViewportView(jList1);

        jLabel5.setText("Message : ");

        jButton4.setText("Send Message ");
        jButton4.setEnabled(false);
        jButton4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton2.setText("Login");
        jButton2.setEnabled(false);
        jButton2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton5.setText("...");
        jButton5.setEnabled(false);





        jButton7.setText("...");
        jButton7.setEnabled(false);
        jButton7.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton8.setText("");
        jButton8.setEnabled(false);


        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                        .addComponent(jSeparator2)
                                        .addComponent(jSeparator1, GroupLayout.Alignment.TRAILING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
                                                        .addComponent(jLabel1)
                                                        .addComponent(jLabel4)
                                                        .addComponent(jLabel7))
                                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                                                        .addComponent(jTextField3)
                                                                        .addComponent(jTextField1))
                                                                .addGap(18, 18, 18)
                                                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
                                                                        .addComponent(jLabel2)
                                                                        .addComponent(jLabel3))
                                                                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                                                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                                                        .addComponent(jTextField2)
                                                                        .addComponent(jPasswordField1)))
                                                        .addComponent(jTextField6))
                                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
                                                        .addComponent(jButton1, GroupLayout.Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
                                                                        .addComponent(jButton2, GroupLayout.PREFERRED_SIZE, 70, GroupLayout.PREFERRED_SIZE)
                                                                        .addComponent(jButton7, GroupLayout.PREFERRED_SIZE, 70, GroupLayout.PREFERRED_SIZE))
                                                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
                                                                        .addComponent(jButton8, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                                        .addComponent(jButton3, GroupLayout.DEFAULT_SIZE, 81, Short.MAX_VALUE)))))
                                        .addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addComponent(jScrollPane1)
                                                .addGap(18, 18, 18)
                                                .addComponent(jScrollPane2, GroupLayout.PREFERRED_SIZE, 108, GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(23, 23, 23)
                                                .addComponent(jLabel6)
                                                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jTextField5, GroupLayout.PREFERRED_SIZE, 378, GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(jButton5, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jButton6, GroupLayout.PREFERRED_SIZE, 77, GroupLayout.PREFERRED_SIZE))
                                        .addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addComponent(jLabel5)
                                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jTextField4)
                                                .addGap(18, 18, 18)
                                                .addComponent(jButton4, GroupLayout.PREFERRED_SIZE, 108, GroupLayout.PREFERRED_SIZE)))
                                .addContainerGap())
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel1)
                                        .addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel2)
                                        .addComponent(jTextField2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jButton1))
                                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                        .addComponent(jTextField3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel3)
                                        .addComponent(jLabel4)
                                        .addComponent(jButton3)
                                        .addComponent(jPasswordField1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jButton2))
                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel7)
                                        .addComponent(jTextField6, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jButton7)
                                        .addComponent(jButton8))
                                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jSeparator1, GroupLayout.PREFERRED_SIZE, 10, GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jScrollPane1)
                                        .addComponent(jScrollPane2, GroupLayout.DEFAULT_SIZE, 264, Short.MAX_VALUE))
                                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                        .addComponent(jButton4)
                                        .addComponent(jLabel5)
                                        .addComponent(jTextField4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jSeparator2, GroupLayout.PREFERRED_SIZE, 10, GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE, false)
                                        .addComponent(jButton6, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jButton5, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel6)
                                        .addComponent(jTextField5, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                .addContainerGap())
        );

////////////////////////////////////////////////////////////////
        ActionListener buttonListener = new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent evt) {
                JButton selectedBtn = (JButton) evt.getSource();
                for (int row = 0; row < grid.length; row++) {
                    for (int col = 0; col < grid[row].length; col++) {
                        if (grid[row][col] == selectedBtn) {
                            target = jList1.getSelectedValue().toString();
                            String msg =   row+"#"+ col;

                            if(!msg.isEmpty() && !target.isEmpty() && flag==true){
                                client.send(new RequestLoginMessage("message", username, msg, target));
                            }

                        }
                    }
                }
            }
        };
        ActionListener coloraction = new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent evt) {
                if (flag==false){
                    JButton selectedBtn = (JButton) evt.getSource();
                    for (int row = 0; row < grid.length; row++) {
                        for (int col = 0; col < grid[row].length; col++) {
                            if (grid[row][col] == selectedBtn) {
                                //grid[row][col].setOpaque(true);
                                //grid[row][col].setBorderPainted(false);
                                //Image img = null;
                                //target=jList1.getSelectedValue().toString();
                                grid[row][col].setIcon(new ImageIcon("c:\\users\\mahnoosh\\desktop\\multiplier.png"));
                                count1++;
                                ArrayList<Integer> m = new ArrayList<>();
                                m.add(0,row);
                                m.add(1,col);
                                colored.add(m);

                            }
                        }
                    }
                }
            }
        };
        ActionListener readyaction = new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent evt) {

                //String target = jList1.getSelectedValue().toString();
                client.send(new RequestLoginMessage("ready", username, "I am ready", "SERVER"));
                flag=true;

            }
        };
        JPanel lettersPanel = new JPanel(new GridLayout(10,10));
        ///////////
        grid=new JButton[10][10];
        for(int y=0; y<10; y++){
            for(int x=0; x<10; x++){
                grid[x][y]=new JButton();
                grid[x][y].setPreferredSize(new Dimension(1, 1));
                grid[x][y].setIcon(new ImageIcon("c:\\users\\mahnoosh\\desktop\\empty.jpg"));
                grid[x][y].addActionListener(buttonListener);
                grid[x][y].addActionListener(coloraction);

                lettersPanel.add(grid[x][y]); //adds button to grid
            }
        }
        //////////

        JButton ready=new JButton();
        ready.addActionListener(readyaction);
        ready.setText("Ready");

        Container contentPane = jFrame.getContentPane();
        contentPane.add(getContentPane(), BorderLayout.NORTH);
        contentPane.add(lettersPanel, BorderLayout.CENTER);
        contentPane.add(ready, BorderLayout.AFTER_LAST_LINE);
        jFrame.setSize(1000,900);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jFrame.setVisible(true);
        //pack();
    }

    private void jButton1ActionPerformed(ActionEvent evt) {
        serverAddr = jTextField1.getText(); port = Integer.parseInt(jTextField2.getText());

        if(!serverAddr.isEmpty() && !jTextField2.getText().isEmpty()){
            try{
                client = new SocketClient(this);
                clientThread = new Thread(client);
                clientThread.start();
                client.send(new RequestLoginMessage("test", "testUser", "testContent", "SERVER"));
            }
            catch(Exception ex){
                jTextArea1.append("[Application > Me] : Server not found\n");
            }
        }
    }

    private void jButton2ActionPerformed(ActionEvent evt) {
        username = jTextField3.getText();
        password = jPasswordField1.getText();

        if(!username.isEmpty() && !password.isEmpty()){
            client.send(new RequestLoginMessage("login", username, password, "SERVER"));
        }
    }

    private void jButton4ActionPerformed(ActionEvent evt) {
        String msg = jTextField4.getText();
        target = jList1.getSelectedValue().toString();

        if(!msg.isEmpty() && !target.isEmpty()){
            jTextField4.setText("");
            client.send(new RequestLoginMessage("message1", username, msg, target));
        }
    }






    private void jButton7ActionPerformed(ActionEvent evt) {
        JFileChooser jf = new JFileChooser();
        jf.showDialog(this, "Select File");

        if(!jf.getSelectedFile().getPath().isEmpty()){
            historyFile = jf.getSelectedFile().getPath();
            //if(this.isWin32()){
              ///  historyFile = historyFile.replace("/", "\\");
            //}
            jTextField6.setText(historyFile);
            jTextField6.setEditable(false);
            jButton7.setEnabled(false);
            jButton8.setEnabled(true);
             hist = new History(historyFile);


        }
    }



    public static void main(String args[]) {
        try {
          //  UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }
        catch(Exception ex){
            System.out.println("exception");
        }

        EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ChatFrame();
            }
        });
    }

    public JButton jButton1;
    public JButton jButton2;
    public JButton jButton3;
    public JButton jButton4;
    public JButton jButton5;
    public JButton jButton6;
    public JButton jButton7;
    public JButton jButton8;
    private JLabel jLabel1;
    private JLabel jLabel2;
    private JLabel jLabel3;
    private JLabel jLabel4;
    private JLabel jLabel5;
    private JLabel jLabel6;
    private JLabel jLabel7;
    public JList jList1;
    public JPasswordField jPasswordField1;
    private JScrollPane jScrollPane1;
    private JScrollPane jScrollPane2;
    private JSeparator jSeparator1;
    private JSeparator jSeparator2;
    public JTextArea jTextArea1;
    public JTextField jTextField1;
    public JTextField jTextField2;
    public JTextField jTextField3;
    public JTextField jTextField4;
    public JTextField jTextField5;
    public JTextField jTextField6;
    // End of variables declaration//GEN-END:variables
}
