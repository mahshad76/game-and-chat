package tools;

import model.RequestLoginMessage;
import view.ChatFrame;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Date;

public class SocketClient implements Runnable{
    public SocketClient client;
    public int port;
    public String serverAddr;
    public Socket socket;
    public ChatFrame ui;
    public ObjectInputStream In;
    public ObjectOutputStream Out;
   public History hist;
    public ArrayList<ArrayList<Integer>> colored=new ArrayList<>();
    public ArrayList<ArrayList<Integer>> uncolored=new ArrayList<>();
    public String turn="";
    public String target="";
    JButton grid[][];
    public ArrayList<ArrayList<Integer>> clicked=new ArrayList<>();
    public ArrayList<ArrayList<Integer>> changed=new ArrayList<>();
    public int count1=0;
    public int count2=0;
    public SocketClient(ChatFrame frame) throws IOException{
        ui = frame;
        client=frame.client;
        colored=frame.colored;

        this.serverAddr = ui.serverAddr; this.port = ui.port;
        socket = new Socket(InetAddress.getByName(serverAddr), port);
        count1=frame.count1;
        Out = new ObjectOutputStream(socket.getOutputStream());
        Out.flush();
        In = new ObjectInputStream(socket.getInputStream());
        hist = ui.hist;


    }

    @Override
    public void run() {
        boolean keepRunning = true;
        while(keepRunning){
            try {
                if(turn.equals("TRUE")){

                    for(int i=0;i<ui.grid.length;i++){
                        for(int j=0;j<ui.grid.length;j++){
                            ui.grid[i][j].setIcon(new ImageIcon("c:\\users\\mahnoosh\\desktop\\empty.jpg"));

                        }
                    }
                   for(int k=0;k<clicked.size();k++) {
                       ui.grid[clicked.get(k).get(0)][clicked.get(k).get(1)].setText("");
                       if(clicked.get(k).get(2)==0)
                       ui.grid[clicked.get(k).get(0)][clicked.get(k).get(1)].setIcon(new ImageIcon("c:\\users\\mahnoosh\\desktop\\circle.jpg"));
                       if(clicked.get(k).get(2)==1)
                           ui.grid[clicked.get(k).get(0)][clicked.get(k).get(1)].setIcon(new ImageIcon("c:\\users\\mahnoosh\\desktop\\tick.png"));
                   }
                    synchronized(this) {
                       wait(1000);
                    }
                }
                if(turn.equals("FALSE")){

                    for(int i=0;i<ui.grid.length;i++){
                        for(int j=0;j<ui.grid.length;j++){
                            ui.grid[i][j].setIcon(new ImageIcon("c:\\users\\mahnoosh\\desktop\\empty.jpg"));

                        }
                    }

                    for(int k=0;k<ui.colored.size();k++){

                       ui.grid[ui.colored.get(k).get(0)][ui.colored.get(k).get(1)].setIcon(new ImageIcon("c:\\users\\mahnoosh\\desktop\\multiplier.png"));
                    }

                    for (int y=0;y<changed.size();y++)
                        ui.grid[changed.get(y).get(0)][changed.get(y).get(1)].setIcon(new ImageIcon("c:\\users\\mahnoosh\\desktop\\red.png"));

                }

                byte[] bb =(byte[])  In.readObject();
                RequestLoginMessage msg1=new  RequestLoginMessage(bb);
                System.out.println("Incoming : "+msg1.getMessageContent()+"   "+msg1.getMessageType());
                if(msg1.getMessageType().equals("message")) {
                    String res = "";
                    if (msg1.getMessageRecepient().equals(ui.username))
                         {
                             if(turn.equals("FALSE")) {

                                 String m[] = msg1.getMessageContent().split("#");
                                 for (int i = 0; i < colored.size(); i++) {
                                     if (colored.get(i).get(0) == Integer.parseInt(m[0]) && colored.get(i).get(1) == Integer.parseInt(m[1])) {
                                         res = "khord#" + Integer.parseInt(m[0]) + "#" + Integer.parseInt(m[1]);
                                         count2++;
                                         if(count2==colored.size())
                                             send(new RequestLoginMessage("win", msg1.getMessageRecepient(), "TRUE", msg1.getMessageSender()));
                                         break;
                                     }
                                 }
                                 if(res=="")
                                     res = "nakhord#"+Integer.parseInt(m[0])+"#"+Integer.parseInt(m[1]);
                                 ArrayList<Integer> me=new ArrayList<>();
                                 me.add(0,Integer.parseInt(m[0]));
                                 me.add(1,Integer.parseInt(m[1]));
                                 changed.add(me);
                                 send(new RequestLoginMessage("hit", msg1.getMessageRecepient(), res, msg1.getMessageSender()));

                             }

                   } else {//jj khodeshe
                        //safe khali ya click ha
                        for(int i=0;i<ui.grid.length;i++){
                            for(int j=0;j<ui.grid.length;j++){
                                ui.grid[i][j].setIcon(new ImageIcon("c:\\users\\mahnoosh\\desktop\\empty.jpg"));
                            }
                        }
                    }
                }
                if(msg1.getMessageType().equals("message1")){
                    if(msg1.getMessageRecepient().equals(ui.username)){
                        ui.jTextArea1.append("["+msg1.getMessageSender() +" > Me] : " + msg1.getMessageContent() + "\n");
                    }
                    else{

                    }


                }
                else if(msg1.getMessageType().equals("hit")){

                    if (msg1.getMessageRecepient().equals(ui.username))//khodamam
                    {

                        String m[]=msg1.getMessageContent().split("#");
                      //  System.out.print(m[0]);
                        if(m[0].equals("khord")){



                            ArrayList<Integer> mm=new ArrayList<>();
                            mm.add(0,Integer.parseInt(m[1]));
                            mm.add(1,Integer.parseInt(m[2]));
                            mm.add(2,1);
                            clicked.add(mm);
                            this.send(new RequestLoginMessage("turn", msg1.getMessageRecepient(), "FALSE", msg1.getMessageSender()));
                        }
                        if(m[0].equals("nakhord")){
                            ArrayList<Integer> mm=new ArrayList<>();
                            mm.add(0,Integer.parseInt(m[1]));
                            mm.add(1,Integer.parseInt(m[2]));
                            mm.add(2,0);
                            clicked.add(mm);
                            this.send(new RequestLoginMessage("turn", msg1.getMessageRecepient(), "TRUE", msg1.getMessageSender()));
                        }

                    }
                    if (!msg1.getMessageRecepient().equals(ui.username))//tarafe
                    {

                    }
                }
                else if(msg1.getMessageType().equals("turn")) {

                    if (msg1.getMessageRecepient().equals(ui.username))//khodamam
                    {
                        turn = msg1.getMessageContent();
                        ui.jTextArea1.append(turn+"  "+"\n");
                        if(turn.equals("TRUE"))
                            this.send(new RequestLoginMessage("nextturn", msg1.getMessageRecepient(), "FALSE", msg1.getMessageSender()));
                        if(turn.equals("FALSE"))
                            this.send(new RequestLoginMessage("nextturn", msg1.getMessageRecepient(), "TRUE", msg1.getMessageSender()));

                    }
                        else {

                        }

                }
                else if(msg1.getMessageType().equals("win")) {
                    if (msg1.getMessageRecepient().equals(ui.username))//khodamam
                    {

                        if(msg1.getMessageContent().equals("TRUE")) {
                            JOptionPane.showMessageDialog(null, ui.username+"  wins the game");
                            ui.jFrame.setVisible(false);
                        }
                    }
                    else {
                        ui.jFrame.setVisible(false);
                    }

                }
                 else if(msg1.getMessageType().equals("ready")){
                    if(msg1.getMessageContent().equals("TRUE")){
                        turn="TRUE";
                        for(int i=0;i<ui.grid.length;i++){
                            for(int j=0;j<ui.grid.length;j++){
                                ui.grid[i][j].setIcon(new ImageIcon("c:\\users\\mahnoosh\\desktop\\empty.jpg"));
                            }
                        }

                    }
                    else{
                        turn="FALSE";
                        ui.jTextArea1.append("not my turn  "+"\n");
                    }
                }
                else if(msg1.getMessageType().equals("nextturn")){
                    if (msg1.getMessageRecepient().equals(ui.username)){
                       turn=msg1.getMessageContent();
                        ui.jTextArea1.append(turn + "  " + "\n");
                    }
                    else{

                    }
                }
                else if(msg1.getMessageType().equals("login")){
                    if(msg1.getMessageContent().equals("TRUE")){
                        ui.jButton2.setEnabled(false); ui.jButton3.setEnabled(false);                        
                        ui.jButton4.setEnabled(true); ui.jButton5.setEnabled(true);
                        ui.jTextArea1.append("[SERVER > Me] : Login Successful\n");
                        ui.jTextField3.setEnabled(false); ui.jPasswordField1.setEnabled(false);
                    }
                    else{
                        ui.jTextArea1.append("[SERVER > Me] : Login Failed\n");
                    }
                }

                else if(msg1.getMessageType().equals("test")){
                    ui.jButton1.setEnabled(false);
                    ui.jButton2.setEnabled(true); ui.jButton3.setEnabled(true);
                    ui.jTextField3.setEnabled(true); ui.jPasswordField1.setEnabled(true);
                    ui.jTextField1.setEditable(false); ui.jTextField2.setEditable(false);
                    ui.jButton7.setEnabled(true);
                }
                else if(msg1.getMessageType().equals("newuser")){
                    if(!msg1.getMessageContent().equals(ui.username)){
                        boolean exists = false;
                        for(int i = 0; i < ui.model.getSize(); i++){
                            if(ui.model.getElementAt(i).equals(msg1.getMessageContent())){
                                exists = true; break;
                            }
                        }
                        if(!exists){ ui.model.addElement(msg1.getMessageContent()); }
                    }
                }




                else{

                }
            }
            catch(Exception ex) {
                keepRunning = false;
                ui.jTextArea1.append("[Application > Me] : Connection Failure\n");
                ui.jButton1.setEnabled(true); ui.jTextField1.setEditable(true); ui.jTextField2.setEditable(true);
                ui.jButton4.setEnabled(false); ui.jButton5.setEnabled(false); ui.jButton5.setEnabled(false);
                
                for(int i = 1; i < ui.model.size(); i++){
                    ui.model.removeElementAt(i);
                }
                
                ui.clientThread.stop();
                
                System.out.println("Exception SocketClient run()");
                ex.printStackTrace();
            }
        }
    }
    
    public void send(RequestLoginMessage msg){
        try {
            Out.writeObject(msg.getSerialized());

            Out.flush();
            //System.out.println("Outgoing : "+msg.toString());
            
            if(msg.getMessageType().equals("message1") ){

                String msgTime = (new Date()).toString();
                try{

                    hist.addMessage(msg, msgTime);

                }
                catch(Exception ex){}
            }
        } 
        catch (IOException ex) {
            System.out.println("Exception SocketClient send()");
        }
    }
    
    public void closeThread(Thread t){
        t = null;
    }
}
