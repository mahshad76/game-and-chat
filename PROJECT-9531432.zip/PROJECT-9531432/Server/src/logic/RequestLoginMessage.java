package logic;

/**
 * Created by mahnoosh on 7/7/2017.
 */
import logic.BaseMessage;
import org.apache.commons.lang3.SerializationUtils;

import java.nio.ByteBuffer;
import java.util.ArrayList;

public class RequestLoginMessage extends BaseMessage {

    private String type;
    private String sender;
    private String recepient;
    private String content;
    public RequestLoginMessage(String type, String sender,String content,String recepient) {
        this.type=type;
        this.sender=sender;
        this.content=content;
        this.recepient=recepient;
        serialize();
    }
    public RequestLoginMessage(byte[] serialized) {
        mSerialized = serialized;
        deserialize();
    }
    @Override     protected void serialize() {
        ArrayList<String> arrayList=new ArrayList<>();
        arrayList.add(0,type);
        arrayList.add(1,sender);
        arrayList.add(2,content);
        arrayList.add(3,recepient);
        mSerialized = SerializationUtils.serialize(arrayList);

    }
    @Override     protected void deserialize() {
        ArrayList<String> arrayList = (ArrayList<String>) SerializationUtils.deserialize(mSerialized);
        type=arrayList.get(0);
        sender=arrayList.get(1);
        content=arrayList.get(2);
        recepient=arrayList.get(3);
    }


    @Override
    public String getMessageType() {
        return type;
    }

    @Override
    public String getMessageSender() {
        return sender;
    }

    @Override
    public String getMessageContent() {
        return content;
    }

    @Override
    public String getMessageRecepient() {
        return recepient;
    }
    public byte[] getSerialized() {         return mSerialized;     }
}
