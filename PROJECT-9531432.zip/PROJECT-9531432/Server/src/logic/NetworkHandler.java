package logic;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 * Created by mahnoosh on 7/8/2017.
 */
public class NetworkHandler extends Thread {

        public TcpChannel tcpChannel;

        public NetworkHandler(MessageManager _server, Socket _socket){
            super();
            tcpChannel=new TcpChannel(_server,_socket);
        }

        public void send(RequestLoginMessage msg){
            try {
                System.out.println(msg.getMessageType());
                tcpChannel.mOutputStream.writeObject(msg.getSerialized());
                tcpChannel.mOutputStream.flush();
            }
            catch (IOException ex) {
                System.out.println("Exception [SocketClient : send(...)]");
            }
        }

        public int getID(){
            return tcpChannel.getID();
        }

        @SuppressWarnings("deprecation")
        public void run(){
            tcpChannel.ui.jTextArea1.append("\nServer Thread " + tcpChannel.getID() + " running.");
            while (true){
                try{
                    byte[] bb =(byte[])  tcpChannel.mInputStream.readObject();
                    RequestLoginMessage msg1=new  RequestLoginMessage(bb);
                    //System.out.println(msg1);
                    tcpChannel.server.handle(tcpChannel.getID(), msg1);
                }
                catch(Exception ioe){
                    System.out.println(getID()+ " ERROR reading: " + ioe.getMessage());
                    tcpChannel.server.remove(tcpChannel.getID());
                    stop();
                }
            }
        }

        public void open() throws IOException {
            tcpChannel.mOutputStream = new ObjectOutputStream(tcpChannel.mSocket.getOutputStream());
            tcpChannel.mOutputStream.flush();
            tcpChannel.mInputStream = new ObjectInputStream(tcpChannel.mSocket.getInputStream());
        }

        public void stopSelf() throws IOException {
            if (tcpChannel.mSocket != null)    tcpChannel.mSocket.close();
            if (tcpChannel.mInputStream != null)  tcpChannel.mInputStream .close();
            if (tcpChannel.mOutputStream != null) tcpChannel.mOutputStream.close();
        }

}
