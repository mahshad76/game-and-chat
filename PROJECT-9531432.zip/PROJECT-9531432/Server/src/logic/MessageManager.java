package logic;

import java.io.*;
import java.net.*;


public class MessageManager implements Runnable {

    public NetworkHandler clients[];
    public ServerSocket server = null;
    public Thread       thread = null;
    public int clientCount = 0, port = 13000;
    public ServerFrame ui;
    public Database db;
    public boolean flag=false;
    public MessageManager(ServerFrame frame){
        clients = new NetworkHandler[50];//50 clients
        ui = frame;
        db = new Database(ui.filePath);

        try{
            server = new ServerSocket(port);
            port = server.getLocalPort();
            ui.jTextArea1.append("Server startet. IP : " + InetAddress.getLocalHost() + ", Port : " + server.getLocalPort());
            start();
        }
        catch(IOException ioe){
            ui.jTextArea1.append("Can not bind to port : " + port + "\nRetrying");
            ui.RetryStart(0);
        }
    }

    public MessageManager(ServerFrame frame, int Port){

        clients = new NetworkHandler[50];
        ui = frame;
        port = Port;
        db = new Database(ui.filePath);

        try{
            server = new ServerSocket(port);
            port = server.getLocalPort();
            ui.jTextArea1.append("Server startet. IP : " + InetAddress.getLocalHost() + ", Port : " + server.getLocalPort());
            start();
        }
        catch(IOException ioe){
            ui.jTextArea1.append("\nCan not bind to port " + port + ": " + ioe.getMessage());
        }
    }

    public void run(){
        while (thread != null){
            try{
                ui.jTextArea1.append("\nWaiting for a client ...");
                addThread(server.accept());
            }
            catch(Exception ioe){
                ui.jTextArea1.append("\nServer accept error: \n");
                ui.RetryStart(0);
            }
        }
    }

    public void start(){
        if (thread == null){
            thread = new Thread(this);
            thread.start();
        }
    }

    @SuppressWarnings("deprecation")
    public void stop(){
        if (thread != null){
            thread.stop();
            thread = null;
        }
    }

    private int
    findClient(int ID){
        for (int i = 0; i < clientCount; i++){
            if (clients[i].getID() == ID){
                return i;
            }
        }
        return -1;
    }

    public synchronized void handle(int ID, RequestLoginMessage msg){

            if(msg.getMessageType().equals("login")){
                    if(db.checkLogin(msg.getMessageSender(), msg.getMessageContent())){
                        clients[findClient(ID)].tcpChannel.username = msg.getMessageSender();
                        clients[findClient(ID)].send(new RequestLoginMessage("login", "SERVER", "TRUE", msg.getMessageSender()));
                        Announce("newuser", "SERVER", msg.getMessageSender());
                        SendUserList(msg.getMessageSender());
                    }
                    else{
                        clients[findClient(ID)].send(new RequestLoginMessage("login", "SERVER", "FALSE", msg.getMessageSender()));
                    }
            }
            else if(msg.getMessageType().equals("message")){

                    findUserThread(msg.getMessageRecepient()).send(new RequestLoginMessage(msg.getMessageType(), msg.getMessageSender(), msg.getMessageContent(), msg.getMessageRecepient()));

            }
            else if(msg.getMessageType().equals("message1")){

                    findUserThread(msg.getMessageRecepient()).send(new RequestLoginMessage(msg.getMessageType(), msg.getMessageSender(), msg.getMessageContent(), msg.getMessageRecepient()));
                    System.out.println(findUserThread(msg.getMessageRecepient()));
                    System.out.println(clients[findClient(ID)]);
            }
            else if(msg.getMessageType().equals("hit")){


                    findUserThread(msg.getMessageRecepient()).send(new RequestLoginMessage(msg.getMessageType(), msg.getMessageSender(), msg.getMessageContent(), msg.getMessageRecepient()));

            }
            else if(msg.getMessageType().equals("win")){



                    findUserThread(msg.getMessageRecepient()).send(new RequestLoginMessage(msg.getMessageType(), msg.getMessageSender(), msg.getMessageContent(), msg.getMessageRecepient()));

            }
            else if(msg.getMessageType().equals("turn")){

                    findUserThread(msg.getMessageRecepient()).send(new RequestLoginMessage(msg.getMessageType(), msg.getMessageSender(), msg.getMessageContent(), msg.getMessageRecepient()));

            } else if(msg.getMessageType().equals("nextturn")){


                    findUserThread(msg.getMessageRecepient()).send(new RequestLoginMessage(msg.getMessageType(), msg.getMessageSender(), msg.getMessageContent(), msg.getMessageRecepient()));

            }
            else if(msg.getMessageType().equals("ready")){

                if(flag==false) {
                    clients[findClient(ID)].send(new RequestLoginMessage("ready", "SERVER", "TRUE", msg.getMessageSender()));
                    flag=true;
                }
                else {
                    clients[findClient(ID)].send(new RequestLoginMessage("ready", "SERVER", "FALSE", msg.getMessageSender()));
                    flag=false;
                }

            }
            else if(msg.getMessageType().equals("test")){

                clients[findClient(ID)].send(new RequestLoginMessage("test", "SERVER", "OK", msg.getMessageSender()));
            }



    }

    public void Announce(String type, String sender, String content){
        RequestLoginMessage msg = new RequestLoginMessage(type, sender, content, "All");
        for(int i = 0; i < clientCount; i++){
            clients[i].send(msg);
        }
    }

    public void SendUserList(String toWhom){
        for(int i = 0; i < clientCount; i++){
            findUserThread(toWhom).send(new RequestLoginMessage("newuser", "SERVER", clients[i].tcpChannel.username, toWhom));
        }
    }

    public NetworkHandler findUserThread(String usr){
        for(int i = 0; i < clientCount; i++){
            if(clients[i].tcpChannel.username.equals(usr)){
                return clients[i];
            }
        }
        return null;
    }

    @SuppressWarnings("deprecation")
    public synchronized void remove(int ID){
        int pos = findClient(ID);
        if (pos >= 0){
            NetworkHandler toTerminate = clients[pos];
            ui.jTextArea1.append("\nRemoving client thread " + ID + " at " + pos);
            if (pos < clientCount-1){
                for (int i = pos+1; i < clientCount; i++){
                    clients[i-1] = clients[i];
                }
            }
            clientCount--;
            try{
                toTerminate.tcpChannel.closeChnnel();
            }
            catch(IOException ioe){
                ui.jTextArea1.append("\nError closing thread: " + ioe);
            }
            toTerminate.stop();
        }
    }

    private void addThread(Socket socket){
        if (clientCount < clients.length){
            ui.jTextArea1.append("\nClient accepted: " + socket);
            clients[clientCount] = new NetworkHandler(this, socket);
            try{
                clients[clientCount].open();
                clients[clientCount].start();
                clientCount++;
            }
            catch(IOException ioe){
                ui.jTextArea1.append("\nError opening thread: " + ioe);
            }
        }
        else{
            ui.jTextArea1.append("\nClient refused: maximum " + clients.length + " reached.");
        }
    }
}
