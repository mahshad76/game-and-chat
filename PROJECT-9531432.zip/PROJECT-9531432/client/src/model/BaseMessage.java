package model;

/**
 * Created by mahnoosh on 7/7/2017.
 */
public abstract class BaseMessage {
    protected byte[] mSerialized;
    /**      * Fields are stored into serial bytes in this method.      */
    protected abstract void serialize();
    /**      * Fields are restored from serial bytes in this method.      */
    protected abstract void deserialize();
    /**      * Return message type code.       */
    public abstract String getMessageType();
    public abstract String getMessageSender();
    public abstract String getMessageContent();
    public abstract String getMessageRecepient();
    public abstract byte[] getSerialized() ;}
