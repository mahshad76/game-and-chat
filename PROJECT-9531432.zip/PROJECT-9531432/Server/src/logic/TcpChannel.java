package logic;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 * Created by mahnoosh on 7/8/2017.
 */
class TcpChannel {

    public MessageManager server = null;
    public Socket mSocket = null;
    public int ID = -1;

    public String username = "";

    public ObjectInputStream mInputStream  =  null;
    public ObjectOutputStream mOutputStream = null;
    public ServerFrame ui;

    public TcpChannel(MessageManager _server, Socket _socket){
        super();
        server = _server;
        mSocket = _socket;
        ID     = mSocket.getPort();
        ui = _server.ui;
    }
    public byte[] read() throws IOException, ClassNotFoundException {
        byte[] bb =(byte[])  mInputStream.readObject();
        return bb;
    }
    public void write(byte[] data) throws IOException {
        mOutputStream.writeObject(data);
        mOutputStream.flush();
    }
    public void isConnected() throws IOException {//open
        mOutputStream = new ObjectOutputStream(mSocket.getOutputStream());
        mOutputStream.flush();
        mInputStream = new ObjectInputStream(mSocket.getInputStream());
    }

    public void closeChnnel() throws IOException {
        if (mSocket != null)    mSocket.close();
        if (mInputStream != null)  mInputStream.close();
        if (mOutputStream != null) mOutputStream.close();
    }


    public int getID(){
        return ID;
    }


}
